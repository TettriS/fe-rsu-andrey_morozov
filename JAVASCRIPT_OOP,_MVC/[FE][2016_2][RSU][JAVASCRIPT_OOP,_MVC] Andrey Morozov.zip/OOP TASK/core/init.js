var app = new Application();
app.start();