var application = new Controller();
application.start();